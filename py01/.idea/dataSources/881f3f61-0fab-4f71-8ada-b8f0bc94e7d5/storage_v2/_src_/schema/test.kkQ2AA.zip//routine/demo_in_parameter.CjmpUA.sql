CREATE PROCEDURE demo_in_parameter(IN p_in INT)
  begin
select p_in;
select p_in=2;
select p_in;
end;

